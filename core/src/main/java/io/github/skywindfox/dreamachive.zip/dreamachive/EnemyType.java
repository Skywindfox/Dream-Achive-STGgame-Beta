package io.github.skywindfox.dreamachive;

public enum EnemyType {
    BASIC,
    FAST,
    TANK,
    BOSS
}
