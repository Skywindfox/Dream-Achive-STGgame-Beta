package io.github.skywindfox.dreamachive;

import java.util.List;

public class LevelData {
    private List<WaveData> waves;

    public List<WaveData> getWaves() {
        return waves;
    }
    
    public void setWaves(List<WaveData> waves) {
        this.waves = waves;
    }
}